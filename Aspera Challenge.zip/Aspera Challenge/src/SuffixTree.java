
public class SuffixTree {
	private Node head;
	
	private class Node {
		public Node[] childeren;
		public char letter;
		public boolean end;
		
		public Node (char letter, boolean end) {
			this.letter= letter;
			this.end = end;
			childeren = new Node[26]; //one for every letter
		}
		
		public boolean hasChild(char c) {
			int index = Character.getNumericValue(c) - 10; //a = 10 - 10 = 0 b = 1 and so on
			if(childeren[index] != null)
				return true; //child was found
			return false;
		}
		
		public void addChild(Node child) {
			int index = Character.getNumericValue(child.letter) - 10;
			childeren[index] = child;
		}
		
		public Node traverse(char c){
			int index = Character.getNumericValue(c) - 10;
			return childeren[index];
		}
	}
	public SuffixTree () {
		head = new Node(' ', false); //the head node
	}
	
	public void build (String word) {
		Node cur = head;
		for(int i = 0; i < word.length(); i++) {
			char c = word.charAt(i);
			boolean end = false;
			
			if(i == word.length() -1) {
				end = true; //its the end of the word and we know it
			}
			if(!cur.hasChild(c)) {
				cur.addChild(new Node(c, end)); //and a child is born
			}
			
			cur = cur.traverse(c); //travle to the child
		}
	}
	public boolean breakUp(String word, int depth) {
		Node cur = head;
		if(word.compareTo("") == 0) {
			if(depth > 1) //if its empty and its made of 2 or more sub words
				return true;
		}
		else {
			for(int i = 0; i < word.length(); i++) {
				char c = word.charAt(i);
				cur = cur.traverse(c);
				if (cur == null) { //no child was found
					return false;
				}
				if(cur.end) { //reached a end of a word
					if(breakUp(word.substring(i + 1), depth + 1)) { //praise the recursion
						return true;
					}
				}
			}
		}
		return false;
	}
}







