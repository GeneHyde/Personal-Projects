import java.util.Scanner;
import java.io.*;

public class Concatenated {

	public static void main(String[] args) throws FileNotFoundException {
		int longest = 0;
		int secondLong = 0;
		String longestString = "";
		String secondLongString = "";
		int count = 0;
		File fopen = new File("./words.txt"); //crack open the file, hope it was ok to hard code
		Scanner fin = new Scanner(fopen);
		
		SuffixTree tree = new SuffixTree();
		
		while(fin.hasNext()) {
			tree.build(fin.nextLine()); //my little tree is growing up into probably a massive tree
		}
		fin.close();
		fin = new Scanner(fopen); //why can't java just have a fin.rewind()?
		while(fin.hasNext()) {
			String word = fin.nextLine();
			if(tree.breakUp(word, 0)) { //if its a concat word
				if(word.length() > longest) { //check to see if it is the longest
					secondLong = longest;
					secondLongString = longestString;
					longest = word.length();
					longestString = word;
				}
				count++; //and count up
			}	
		}
        //and the results are in
		System.out.println("The longest concatinated string was: " + longestString + ", at " + longest + " letters.");
		System.out.println("The second longest concatinated string was: " + secondLongString + ", at " + secondLong + " letters.");
		System.out.println("The number of strings that are concatinated is: " + count);
		
		fin.close(); //so little clean up
        
	}
}
